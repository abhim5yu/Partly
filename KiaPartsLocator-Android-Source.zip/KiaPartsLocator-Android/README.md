# Kia Parts Locator

Android WebView app for the Bento-style Kia Parts Locator.

## Build APK using GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this project to the repository root.
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build Kia Parts Locator APK** using **Run workflow**, or push a commit to `main`.
5. Download `app-debug.apk` from the workflow's Artifacts section. The workflow also updates the repository's `latest` release.

## App details

- App name: Kia Parts Locator
- Package: `com.abhimanyu.kiaparts`
- Minimum Android: 10 (API 29)
- Storage: WebView localStorage, stored on-device
- No account or backend required

## Updating

Install a newer APK over the existing app. Do not uninstall the app first. Uninstalling clears its local app data.

The HTML app is in `app/src/main/assets/index.html`.
