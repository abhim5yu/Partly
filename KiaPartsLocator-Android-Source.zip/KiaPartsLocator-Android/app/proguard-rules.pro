# No custom rules are required. The WebView shell uses platform APIs only.
